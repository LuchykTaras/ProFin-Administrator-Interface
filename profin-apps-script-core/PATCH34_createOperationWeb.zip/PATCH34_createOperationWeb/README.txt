PROFIN OS — ROADMAP PATCH 34
createOperationWeb -> real Apps Script domain core

APPS SCRIPT:
1. Add new file webAdapterCreateOperation.js.
2. Replace inputOperations.js with included version OR apply inputOperations.PATCH34.diff manually.
3. Replace webAdapterTransport.js with included version OR apply webAdapterTransport.PATCH34.diff manually.
4. Do NOT replace webAdapterSecurity.js, webAdapterReplayGuard.js, webAdapterSchemaGuard.js or webAdapterIdempotency.js.
5. clasp push --force
6. Create a new version and update the SAME Web App deployment used by .env.local.

NEXT.JS:
1. Replace:
   lib/contracts/apps-script-adapter.ts
   lib/contracts/operations.ts
   lib/server/apps-script-route.ts
   lib/server/apps-script-transport.ts
2. Add:
   app/api/operations/create/route.ts
3. npm run build

PATCH 34 keeps existing domain rules in Apps Script. It does not reimplement validation, ID generation, FEFO/FIFO, inventory, vaccine/package accruals or rollback in TypeScript.

Intentionally NOT web-enabled in PATCH 34:
- new-client creation inside the operation;
- Asset operation path;
- Vaccine status-change path.
Those existing branches still depend directly on input-sheet cells and must not be simulated by the web adapter.
